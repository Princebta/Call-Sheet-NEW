import { useAuthStore } from "~/stores/authStore";

export function usePermissions() {
  const user = useAuthStore((state) => state.user);
  // Ensure permissions is always an array, even if user.permissions is null, undefined, or not an array
  const permissions = Array.isArray(user?.permissions) ? user.permissions : [];
  const role = user?.role;

  // Generic permission check
  const hasPermission = (permissionName: string): boolean => {
    return permissions.includes(permissionName);
  };

  // Check if user has any of the allowed permissions
  const hasAnyPermission = (permissionNames: string[]): boolean => {
    return permissionNames.some((perm) => permissions.includes(perm));
  };

  // Permission helper functions
  const canManageScenes = (): boolean => {
    return hasPermission("manage_scenes");
  };

  const canViewScenes = (): boolean => {
    return hasPermission("view_scenes");
  };

  const canManageTimers = (): boolean => {
    return hasPermission("manage_timers");
  };

  const canMarkSceneComplete = (): boolean => {
    return hasPermission("mark_scene_complete");
  };

  const canManageTeam = (): boolean => {
    return hasPermission("manage_team");
  };

  const canViewTeam = (): boolean => {
    return hasPermission("view_team");
  };

  const canManageCompany = (): boolean => {
    return hasPermission("manage_company");
  };

  const canManageReports = (): boolean => {
    return hasPermission("manage_reports");
  };

  const canViewReports = (): boolean => {
    return hasPermission("view_reports");
  };

  const canInviteUsers = (): boolean => {
    return hasPermission("manage_team");
  };

  const canManageShows = (): boolean => {
    return hasPermission("manage_shows");
  };

  const canViewShows = (): boolean => {
    return hasPermission("view_shows");
  };

  const canViewTeamPage = (): boolean => {
    return hasPermission("manage_team") || hasPermission("view_team");
  };

  const canViewReportsPage = (): boolean => {
    return hasPermission("manage_reports") || hasPermission("view_reports");
  };

  const canAccessRecipientGroups = (): boolean => {
    return hasPermission("manage_recipient_groups");
  };

  const canManageRoles = (): boolean => {
    return hasPermission("manage_roles");
  };

  const canSendAnnouncements = (): boolean => {
    return hasPermission("send_announcements");
  };

  const canViewAnnouncements = (): boolean => {
    return hasPermission("view_announcements");
  };

  const canSendMessages = (): boolean => {
    return hasPermission("send_messages");
  };

  const canViewMessages = (): boolean => {
    return hasPermission("view_messages");
  };

  const canManageProductionHouses = (): boolean => {
    return hasPermission("manage_production_houses");
  };

  const canViewProductionHouses = (): boolean => {
    return hasPermission("view_production_houses");
  };

  const isActor = (): boolean => {
    return role === "Actor";
  };

  const isDeveloper = (): boolean => {
    return role === "Developer";
  };

  const isAdmin = (): boolean => {
    return role === "Admin";
  };

  const isManager = (): boolean => {
    return role === "Manager";
  };

  const isViewer = (): boolean => {
    return role === "Viewer";
  };

  // For backward compatibility - check if user has a specific role name
  const hasRole = (allowedRoles: string[]): boolean => {
    if (!role) return false;
    return allowedRoles.includes(role);
  };

  return {
    role,
    permissions,
    hasPermission,
    hasAnyPermission,
    hasRole,
    canManageScenes,
    canViewScenes,
    canManageTimers,
    canMarkSceneComplete,
    canManageTeam,
    canViewTeam,
    canManageCompany,
    canManageReports,
    canViewReports,
    canInviteUsers,
    canManageShows,
    canViewShows,
    canViewTeamPage,
    canViewReportsPage,
    canAccessRecipientGroups,
    canManageRoles,
    canSendAnnouncements,
    canViewAnnouncements,
    canSendMessages,
    canViewMessages,
    canManageProductionHouses,
    canViewProductionHouses,
    isActor,
    isDeveloper,
    isAdmin,
    isManager,
    isViewer,
  };
}
