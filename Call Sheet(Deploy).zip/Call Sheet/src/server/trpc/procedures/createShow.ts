import { z } from "zod";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";
import { authenticateUser, checkPermission } from "~/server/utils/auth";

export const createShow = baseProcedure
  .input(
    z.object({
      token: z.string(),
      title: z.string().min(1),
      productionHouseId: z.number(),
      description: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      status: z.enum(["Pre-Production", "Shooting", "Wrapped"]).optional(),
    })
  )
  .mutation(async ({ input }) => {
    const { user, payload } = await authenticateUser(input.token);
    checkPermission(payload.permissions, "manage_shows");

    const show = await db.show.create({
      data: {
        companyId: user.companyId,
        title: input.title,
        productionHouseId: input.productionHouseId,
        description: input.description,
        startDate: input.startDate ? new Date(input.startDate) : null,
        endDate: input.endDate ? new Date(input.endDate) : null,
        status: input.status || "Pre-Production",
        createdBy: user.id,
      },
    });

    return {
      id: show.id,
      title: show.title,
      productionHouseId: show.productionHouseId,
      description: show.description,
      status: show.status,
      startDate: show.startDate,
      endDate: show.endDate,
    };
  });
