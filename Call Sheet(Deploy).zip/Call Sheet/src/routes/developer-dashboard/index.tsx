import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";
import { useAuthStore } from "~/stores/authStore";
import { usePermissions } from "~/hooks/usePermissions";
import { DashboardLayout } from "~/components/DashboardLayout";
import { SystemHealthCard } from "~/components/SystemHealthCard";
import { UsageStatisticsCard } from "~/components/UsageStatisticsCard";
import {
  Settings,
  Users,
  Building2,
  Shield,
  FileText,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  AlertTriangle,
} from "lucide-react";

export const Route = createFileRoute("/developer-dashboard/")({
  component: DeveloperDashboardPage,
});

function DeveloperDashboardPage() {
  const trpc = useTRPC();
  const { token, user } = useAuthStore();
  const permissions = usePermissions();

  // Check if user is a developer
  if (!permissions.isDeveloper()) {
    return (
      <DashboardLayout>
        <div className="p-6 lg:p-8">
          <div className="max-w-2xl mx-auto text-center py-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-red-500/20 rounded-full mb-4">
              <XCircle className="h-8 w-8 text-red-400" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">
              Access Denied
            </h1>
            <p className="text-gray-400 mb-6">
              This dashboard is only accessible to developer users.
            </p>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 px-6 py-3 bg-cinematic-gold-500 text-gray-950 rounded-lg hover:bg-cinematic-gold-600 transition-colors font-semibold"
            >
              Go to Main Dashboard
            </Link>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  const systemHealthQuery = useQuery(
    trpc.getSystemHealth.queryOptions({ token: token || "" })
  );

  const usageStatsQuery = useQuery(
    trpc.getUsageStatistics.queryOptions({ token: token || "" })
  );

  const companiesQuery = useQuery(
    trpc.getAllCompanies.queryOptions({ token: token || "" })
  );

  const isLoading =
    systemHealthQuery.isLoading ||
    usageStatsQuery.isLoading ||
    companiesQuery.isLoading;

  return (
    <DashboardLayout>
      <div className="p-6 lg:p-8 space-y-8">
        {/* Header */}
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-cinematic-gold-500/20 rounded-lg">
              <Settings className="h-6 w-6 text-cinematic-gold-400" />
            </div>
            <h1 className="text-3xl font-bold text-white">
              Developer Dashboard
            </h1>
          </div>
          <p className="text-gray-400">
            System administration and monitoring
          </p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-12 w-12 animate-spin text-cinematic-gold-500" />
          </div>
        ) : (
          <>
            {/* System Health and Usage Stats Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {systemHealthQuery.data && (
                <SystemHealthCard health={systemHealthQuery.data} />
              )}
              {usageStatsQuery.data && (
                <UsageStatisticsCard statistics={usageStatsQuery.data} />
              )}
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-900/50 border border-gray-800 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">
                Quick Actions
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <QuickActionButton
                  icon={Building2}
                  label="View All Companies"
                  description="Manage companies"
                  onClick={() => {
                    document
                      .getElementById("companies-section")
                      ?.scrollIntoView({ behavior: "smooth" });
                  }}
                />
                <QuickActionButton
                  icon={Users}
                  label="Team Management"
                  href="/team"
                  description="View all users"
                />
                <QuickActionButton
                  icon={Shield}
                  label="Roles & Permissions"
                  href="/settings"
                  description="Configure access"
                />
                <QuickActionButton
                  icon={FileText}
                  label="System Reports"
                  href="/reports"
                  description="View analytics"
                />
              </div>
            </div>

            {/* Companies List */}
            {companiesQuery.data && (
              <div
                id="companies-section"
                className="bg-gradient-to-br from-gray-900 to-gray-900/50 border border-gray-800 rounded-2xl p-6"
              >
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-white mb-1">
                      All Companies
                    </h2>
                    <p className="text-sm text-gray-400">
                      {companiesQuery.data.companies.length} total companies
                    </p>
                  </div>
                </div>

                {companiesQuery.data.companies.length === 0 ? (
                  <div className="text-center py-12">
                    <Building2 className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No companies registered yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {companiesQuery.data.companies.map((company) => (
                      <CompanyCard key={company.id} company={company} />
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}

interface QuickActionButtonProps {
  icon: React.ElementType;
  label: string;
  description: string;
  href?: string;
  onClick?: () => void;
}

function QuickActionButton({
  icon: Icon,
  label,
  description,
  href,
  onClick,
}: QuickActionButtonProps) {
  const content = (
    <>
      <div className="p-3 bg-cinematic-gold-500/20 rounded-lg group-hover:bg-cinematic-gold-500/30 transition-colors mb-3">
        <Icon className="h-6 w-6 text-cinematic-gold-400" />
      </div>
      <div>
        <h3 className="font-semibold text-white group-hover:text-cinematic-gold-400 transition-colors mb-1">
          {label}
        </h3>
        <p className="text-xs text-gray-500">{description}</p>
      </div>
    </>
  );

  if (href) {
    return (
      <Link
        to={href}
        className="block p-4 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 rounded-xl transition-all group"
      >
        {content}
      </Link>
    );
  }

  return (
    <button
      onClick={onClick}
      className="w-full text-left p-4 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 rounded-xl transition-all group"
    >
      {content}
    </button>
  );
}

interface CompanyCardProps {
  company: {
    id: number;
    name: string;
    email: string;
    subscriptionTier: string;
    isActive: boolean;
    approvedByDeveloper: boolean;
    createdAt: Date;
    userCount: number;
    showCount: number;
    sceneCount: number;
    reportCount: number;
  };
}

function CompanyCard({ company }: CompanyCardProps) {
  const statusColor = company.isActive
    ? "bg-cinematic-emerald-500/20 text-cinematic-emerald-400"
    : "bg-gray-700 text-gray-400";

  const approvalColor = company.approvedByDeveloper
    ? "bg-cinematic-blue-500/20 text-cinematic-blue-400"
    : "bg-amber-500/20 text-amber-400";

  return (
    <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-xl hover:border-gray-600 transition-colors">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-lg font-semibold text-white">{company.name}</h3>
            <span
              className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor}`}
            >
              {company.isActive ? (
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  Active
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  <XCircle className="h-3 w-3" />
                  Inactive
                </span>
              )}
            </span>
            <span
              className={`px-2 py-1 rounded-full text-xs font-medium ${approvalColor}`}
            >
              {company.approvedByDeveloper ? (
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  Approved
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  Pending Approval
                </span>
              )}
            </span>
          </div>
          <p className="text-sm text-gray-400 mb-2">{company.email}</p>
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Users className="h-3 w-3" />
              {company.userCount} users
            </span>
            <span className="flex items-center gap-1">
              <Building2 className="h-3 w-3" />
              {company.showCount} shows
            </span>
            <span className="flex items-center gap-1">
              <FileText className="h-3 w-3" />
              {company.sceneCount} scenes
            </span>
            <span className="flex items-center gap-1">
              <FileText className="h-3 w-3" />
              {company.reportCount} reports
            </span>
          </div>
        </div>
        <div className="text-right">
          <div
            className={`px-3 py-1 rounded-full text-xs font-medium mb-2 ${
              company.subscriptionTier === "Enterprise"
                ? "bg-cinematic-gold-500/20 text-cinematic-gold-400"
                : company.subscriptionTier === "Pro"
                ? "bg-cinematic-blue-500/20 text-cinematic-blue-400"
                : "bg-gray-700 text-gray-400"
            }`}
          >
            {company.subscriptionTier}
          </div>
          <div className="flex items-center gap-1 text-xs text-gray-500">
            <Clock className="h-3 w-3" />
            {new Date(company.createdAt).toLocaleDateString()}
          </div>
        </div>
      </div>
    </div>
  );
}
